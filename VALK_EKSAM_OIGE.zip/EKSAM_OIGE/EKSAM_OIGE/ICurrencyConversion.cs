﻿using System;
namespace EKSAM_OIGE
{
    public interface ICurrencyConversion_
    {
    }
}
