﻿using System;
namespace EKSAM_OIGE
{
    public class AddCustomerData
    {
        public AddCustomerData()
        {
        }
    }
}
