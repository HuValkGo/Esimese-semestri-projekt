using Microsoft.VisualStudio.TestTools.UnitTesting;
using EKSAM_OIGE;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace EKSAM_TEST
{
    [TestClass]
    public class UnitTest1
    {
        private BankA a = new BankA();
        private BankB b = new BankB();
        private BankC c = new BankC();
        [TestInitialize]
        public void TestMethod1()
        {
            a.AddCustomerData("Hugo", 19, 1000, 500);
            c.AddCustomerData("Aadu", 50, 5000, 20);
            b.AddCustomerData("Seedu", 64, 500, 200);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_1()
        {
            double result = a.ExchangeCurrency(20,"usd");
            Assert.AreEqual(18, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_2()
        {
            double result = b.ExchangeCurrency(20, "AuD");
            Assert.AreEqual(28, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_3()
        {
            double result = a.ExchangeCurrency(10, "rub");
            Assert.AreEqual(700, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_4()
        {
            double result = a.ExchangeCurrency(10, "ils");
            Assert.AreEqual(34, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_5()
        {
            double result = a.ExchangeCurrency(10, "RON");
            Assert.AreEqual(43, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_6()
        {
            double result = c.ExchangeCurrencyFromAToB(10, "RON","Aud");
            Assert.AreEqual(0, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_7()
        {
            double result = c.ExchangeCurrencyFromAToB(100, "aud", "usd");
            Assert.AreEqual(54, result);
        }
        [TestMethod]
        public void Test_GetLoan_1()
        {
            double result = a.GetLoan(1000);
            Assert.AreEqual(53000, result);
        }
        [TestMethod]
        public void Test_GetLoan_2()
        {
            double result = a.GetLoan(100);
            Assert.AreEqual(53900, result);
        }
        [TestMethod]
        public void Test_GetLoan_3()
        {
            double result = a.GetLoan(20000);
            Assert.AreEqual(34000, result);
        }
        [TestMethod]
        public void Test_GetLoan_4()
        {
            double result = b.GetLoan(10);
            Assert.AreEqual(890, result);
        }
        [TestMethod]
        public void Test_GetLoan_5()
        {
            double result = b.GetLoan(1500);
            Assert.AreEqual(0, result);
        }
        [TestMethod]
        public void Test_GetLoan_6()
        {
            double result = b.GetLoan(1000000);
            Assert.AreEqual(0, result);
        }
        [TestMethod]
        public void Test_GetLoan_7()
        {
            double result = b.GetLoan(7000);
            Assert.AreEqual(0, result);
        }
        [TestMethod]
        public void Test_CalulateMaxLoan_1()
        {
            double result = b.CalculateMaxLoan();
            Assert.AreEqual(900, result);
        }
        [TestMethod]
        public void Test_CalculateMaxLoan_2()
        {
            b.AddCustomerData("Peedu", 7, 500, 10);
            double result = b.CalculateMaxLoan();
            Assert.AreEqual(44100, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_8()
        {
            double result = c.ExchangeCurrencyFromAToB(100, "usd", "thb");
            Assert.AreEqual(2626, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_9()
        {
            double result = c.ExchangeCurrencyFromAToB(100, "aud", "thb");
            Assert.AreEqual(1659, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_10()
        {
            double result = a.ExchangeCurrency(100, "inr");
            Assert.AreEqual(7852, result);
        }
        [TestMethod]
        public void Test_ExchangeCurrency_11()
        {
            double result = a.ExchangeCurrency(20, "gBP");
            Assert.AreEqual(12 , result);
        }

    }
}
